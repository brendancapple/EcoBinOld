// EcoBin
// Brendan Apple, Marcellus Day, Alex Hinkle

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;

public class App extends Application 
{ 
  private Scene homeScene;
  private Scene infoScene;
  private HashMap<String, Item> dataTable;
  private ArrayList<String> itemNames;
  
  @Override
  public void start(Stage primaryStage) {
    // Home Scene Stuff
    HBox initialSearchArea;
    VBox homeSceneFill;
    VBox logoBar;
    Label logo;
    Label searchLabel; 
    TextField searchbar;
    Button searchButton;
    Label dne;

    VBox homeBackgroundBox;
    VBox infoBackgroundBox;

    // Info Scene Stuff
    HBox toolbar;
    VBox infoSceneFill;
    HBox infoSeparator;
    VBox RecycleHub;
    VBox AltHub;
    VBox ReuseHub;
    Label name;
    Label recycleLabel;
    Label recycle;
    Label altLabel;
    Label alternatives;
    Label reuseLabel;
    Label reuse;
    Button backButton;

    // Set Up Scenes
    searchbar = new TextField("");
    searchbar.setMaxWidth(200);

    logo = new Label("EcoBin");
    logo.getStyleClass().add("logoLabel");
    logoBar = new VBox(logo);
    logoBar.setAlignment(Pos.TOP_CENTER);
    logoBar.getStyleClass().add("logo");

    searchLabel = new Label("Search for Your Item");
    searchLabel.getStyleClass().add("label-heading");
    dne = new Label("That Item Isn't in Our Database");
    dne.getStyleClass().add("other-heading");
    searchButton = new Button(" > "); 
    searchButton.getStyleClass().add("prettyButtons");

    backButton = new Button(" < ");
    backButton.getStyleClass().add("prettyButtons");
    recycleLabel = new Label("Recycle:");
    recycleLabel.getStyleClass().add("other-heading");
    altLabel = new Label("Alternatives:");
    altLabel.getStyleClass().add("other-heading");
    reuseLabel = new Label("Reuse:");
    reuseLabel.getStyleClass().add("other-heading");
    name = new Label("");
    name.getStyleClass().add("label-heading");
    recycle = new Label("");
    recycle.getStyleClass().add("text");
    alternatives = new Label("");
    alternatives.getStyleClass().add("text");
    reuse = new Label("");
    reuse.getStyleClass().add("text");

    initialSearchArea = new HBox(searchbar, searchButton);
    initialSearchArea.setSpacing(10);
    initialSearchArea.setAlignment(Pos.CENTER);
    homeSceneFill = new VBox(searchLabel, initialSearchArea);
    homeSceneFill.setSpacing(20);
    homeSceneFill.setAlignment(Pos.CENTER);
    homeSceneFill.getStyleClass().add("test");

    toolbar = new HBox(backButton);
    toolbar.setSpacing(10);
    toolbar.setAlignment(Pos.TOP_LEFT);

    RecycleHub = new VBox(recycleLabel, recycle);
    RecycleHub.setSpacing(10);
    RecycleHub.getStyleClass().add("boxBorders");
    AltHub = new VBox(altLabel, alternatives);
    AltHub.setSpacing(10);
    AltHub.getStyleClass().add("boxBorders");
    ReuseHub = new VBox(reuseLabel, reuse);
    ReuseHub.setSpacing(10);

    infoSeparator = new HBox(RecycleHub, AltHub, ReuseHub);
    infoSeparator.setSpacing(20);
    infoSeparator.setAlignment(Pos.TOP_CENTER);

    infoSceneFill = new VBox(toolbar, name, infoSeparator);
    infoSceneFill.setSpacing(30);
    infoSceneFill.setAlignment(Pos.TOP_CENTER);
    infoSceneFill.getStyleClass().add("test");

    homeBackgroundBox = new VBox(logoBar, homeSceneFill);
    homeBackgroundBox.setPadding(new Insets(100));
    homeBackgroundBox.setSpacing(40);
    homeBackgroundBox.setAlignment(Pos.TOP_CENTER);
    homeBackgroundBox.getStyleClass().add("background");
    infoBackgroundBox = new VBox(infoSceneFill);
    infoBackgroundBox.setPadding(new Insets(100));
    infoBackgroundBox.setAlignment(Pos.TOP_CENTER);
    infoBackgroundBox.getStyleClass().add("background");

    homeScene = new Scene(homeBackgroundBox, 1280, 720);
    infoScene = new Scene(infoBackgroundBox, 1280, 720);

    // Load in Data
    itemNames = new ArrayList<String>();
    dataTable = new HashMap<String, Item>();
    dataTable = dataFill(dataTable, itemNames);

    // Load Stages and CSS
    homeScene.getStylesheets().add("fancyBritishBoy.css");  
    infoScene.getStylesheets().add("fancyBritishBoy.css"); 

    // Key Logic
    homeScene.setOnKeyPressed(new EventHandler<KeyEvent>() {
        @Override
        public void handle(KeyEvent event)
        {
            String keycode = event.getCode().toString();
            System.out.println(keycode);

            if (keycode.equals("ENTER")) {
                String query = searchbar.getText().toLowerCase();
                searchbar.setText("");
                Item result = dataTable.get(query);
                // label.setText(tf.getText());

                if (result == null) {
                    dne.setText(query.substring(0,1).toUpperCase() + 
                        query.substring(1) + " Isn't in Our Database, Do you mean " + 
                            recommendation(query, itemNames).toUpperCase() + "?");
                    homeSceneFill.getChildren().add(dne);
                } else {
                    homeSceneFill.getChildren().remove(dne);
                    name.setText(result.getName().trim());
                    recycle.setText(Item.formatStuff(result.getRecycling().trim()));
                    alternatives.setText(Item.formatStuff(result.getAlternatives().trim()));
                    reuse.setText(Item.formatStuff(result.getReuse().trim()));
                    
                    primaryStage.setScene(infoScene);
                }
            }
        }
    });

    // Button Logic
    searchButton.setOnAction(new EventHandler<ActionEvent>() {
        @Override public void handle(ActionEvent e) {
            String query = searchbar.getText().toLowerCase();
            searchbar.setText("");
            Item result = dataTable.get(query);
            // label.setText(tf.getText());
    
            if (result == null) {
                dne.setText(query.substring(0,1).toUpperCase() + 
                    query.substring(1) + " Isn't in Our Database,\nDo you mean " + 
                        recommendation(query, itemNames).toUpperCase() + "?");
                homeSceneFill.getChildren().add(dne);
            } else {
                homeSceneFill.getChildren().remove(dne);
            }
    
            name.setText(result.getName().trim());
            recycle.setText(Item.formatStuff(result.getRecycling().trim()));
            alternatives.setText(Item.formatStuff(result.getAlternatives().trim()));
            reuse.setText(Item.formatStuff(result.getReuse().trim()));
            
            primaryStage.setScene(infoScene);
        }
    });
  
    backButton.setOnAction(new EventHandler<ActionEvent>() {
        @Override public void handle(ActionEvent e) {
            primaryStage.setScene(homeScene);
        }
    });
    
    primaryStage.setTitle("EcoBin");
    primaryStage.setScene(homeScene);
    primaryStage.show();
  } 
    
  public static void main(String[] args) {
    launch(args);
  }

  public static HashMap<String, Item> dataFill(HashMap<String, Item> data, ArrayList<String> names) {
    String content = "";
    try {
      content = Files.readString(Paths.get("Data.txt"));
    } catch (IOException e) {
      System.err.println(e);
    }
    String[] datarray = content.split("@");

    for (String s : datarray) {
      Item temp = new Item(s);
      data.put(temp.getName().toLowerCase(), temp);
      names.add(temp.getName());
    }

    return data;
  }

  public static String recommendation(String input, ArrayList<String> names) {
    String inputInfo = input.toLowerCase();
    // System.out.println(names);
    while (inputInfo.length() > 0) {
        System.err.println(inputInfo);
        for (String s : names) {
            if (s.toLowerCase().contains(inputInfo)) {
                System.out.println(s);
                return s;
            }
        }
        inputInfo = inputInfo.substring(0, inputInfo.length()-1);
    }
    
    return "N/A";
  }
} 
